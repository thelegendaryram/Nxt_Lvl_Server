import nuke
nuke.pluginAddPath("stamps")